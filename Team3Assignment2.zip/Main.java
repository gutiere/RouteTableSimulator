/**
 * Main class to run our route table by creating a route object.
 */

public class Main {
    public static void main(String[] theArgs) {
        RoutingTable myTable = new RoutingTable();
        myTable.run();
    }
}
